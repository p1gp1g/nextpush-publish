<div id="uppush-admin" class="section">
<h2>UnifiedPush Provider Settings</h2>
<br>
<div>
<b>You have an error with your redis server:</b><br>
<?php echo $_['error']; ?>
</div>
